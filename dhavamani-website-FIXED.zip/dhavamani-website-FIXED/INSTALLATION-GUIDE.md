# Dhavamani Technologies Website - Installation & Configuration Guide

## Overview
This updated website includes:
- ✅ Real product images (Embedded Control System & Micro Hydro Power Plant Controllers)
- ✅ Cloud Network & Storage visualization
- ✅ Fully functional contact form with email notifications
- ✅ Auto-reply system for customer inquiries
- ✅ Professional responsive design

## Recent Updates

### 1. **Image Updates**
- **Embedded Control System**: Now displays the actual product image (`images/embedded-control-system.webp`)
- **Micro Hydro Power Plant Controllers**: Now displays actual controller panels (`images/hydro-power-controllers.webp`)
- **Cloud Network Section**: Professional SVG diagram replacing stock photo (`images/cloud-network.svg`)

### 2. **Contact Form Enhancement**
- Fully functional form with PHP backend
- Email notifications sent to: `dhavamanitechnologies@gmail.com` and `contact@dhava.in`
- Auto-reply emails to customers
- Form validation and error handling
- AJAX submission (no page reload)

## Installation Instructions

### Step 1: Upload Files to Your Web Server

Upload all files to your web hosting via FTP/SFTP or cPanel File Manager:
```
/public_html/
├── index.html
├── css/
├── images/
├── js/
└── php/
```

### Step 2: Configure Email Settings

Open `php/contact.php` and update the following settings:

```php
// Line 52-54: Update recipient emails
$to = "dhavamanitechnologies@gmail.com, contact@dhava.in";
$subject = "New Contact Form Submission - Dhavamani Technologies";
$from_email = "noreply@dhava.in"; // Must be from your domain
```

**Important Email Configuration:**
- The `$from_email` must be an email from YOUR domain (e.g., `noreply@dhava.in`)
- Many servers reject emails with mismatched from addresses
- Contact your hosting provider to configure proper email headers

### Step 3: Test the Contact Form

1. Visit your website
2. Scroll to the Contact section
3. Fill out the form with test data
4. Click "Book Free Consultation"
5. Check for success message
6. Verify emails arrived at both recipient addresses

### Step 4: Optional Database Integration

If you want to store form submissions in a database:

1. Uncomment the database function in `php/contact.php` (lines 116-145)
2. Create database table using the SQL provided (lines 148-159)
3. Update database credentials in the `saveToDB()` function
4. Uncomment line 78 to enable database saving

**Database Table SQL:**
```sql
CREATE TABLE contact_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT
);
```

## Email Configuration Troubleshooting

### If emails are not being received:

**Option 1: Use SMTP (Recommended)**
Install PHPMailer and configure SMTP:
```bash
composer require phpmailer/phpmailer
```

**Option 2: Configure PHP mail() function**
Contact your hosting provider to ensure:
- PHP `mail()` function is enabled
- SPF records are configured
- Your domain has valid MX records

**Option 3: Use Third-Party Email Service**
Consider using:
- SendGrid
- Mailgun
- AWS SES
- SMTP2GO

### Common Email Issues:

1. **Emails going to spam**
   - Add SPF and DKIM records to your domain
   - Use a valid from address from your domain
   - Avoid spam trigger words in subject/body

2. **Emails not sending**
   - Check PHP error logs
   - Verify `mail()` function is enabled
   - Test with a simple PHP mail script

3. **Auto-reply not working**
   - Ensure the `sendAutoReply()` function is being called (line 81)
   - Check email headers are correct

## Form Submission Flow

1. User fills out form and clicks submit
2. JavaScript prevents default form submission
3. Form data sent via AJAX to `php/contact.php`
4. PHP validates and sanitizes input
5. Email sent to company addresses
6. Auto-reply sent to customer
7. (Optional) Data saved to database
8. JSON response returned to browser
9. Success/error message displayed

## File Structure

```
dhavamani-website-updated/
├── index.html                          # Main website file (UPDATED)
├── index-backup.html                   # Backup of original
├── INSTALLATION-GUIDE.md              # This file
├── README.md                          # Original README
│
├── css/
│   ├── style.css                      # Main stylesheet
│   ├── style-with-images.css          # Image-enhanced styles
│   ├── style-animated.css             # Animation styles
│   └── ...
│
├── images/
│   ├── embedded-control-system.webp   # NEW: Product photo
│   ├── hydro-power-controllers.webp   # NEW: Product photo
│   ├── cloud-network.svg              # NEW: Network diagram
│   ├── dhavamani-logo-transparent.png
│   └── ...
│
├── js/
│   └── script.js                      # JavaScript utilities
│
└── php/
    └── contact.php                     # Contact form handler (CONFIGURED)
```

## Contact Form Fields

The form collects:
- **Name** (required) - Customer's full name
- **Email** (required) - Customer's email address
- **Phone** (optional) - Customer's phone number
- **Message** (required) - Customer's inquiry details

All fields are sanitized and validated before processing.

## Security Features

✅ Input sanitization with `strip_tags()`
✅ Email validation with `filter_var()`
✅ CSRF protection (POST method only)
✅ XSS prevention
✅ SQL injection protection (if using database)
✅ IP address logging
✅ Timestamp logging

## Browser Compatibility

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers (iOS/Android)

## Performance Optimizations

- WebP images for better compression
- SVG graphics for scalability
- CSS minification ready
- Lazy loading compatible
- Mobile-first responsive design

## Support & Maintenance

For technical support or customization:
- **Email**: dhavamanitechnologies@gmail.com
- **Phone**: +91 94451 25622
- **Location**: Coimbatore, Tamil Nadu, India

## Deployment Checklist

Before going live:

- [ ] Upload all files to web server
- [ ] Update email addresses in `contact.php`
- [ ] Configure domain email (noreply@yourdomain.com)
- [ ] Test contact form submission
- [ ] Verify emails are received
- [ ] Check auto-reply functionality
- [ ] Test on mobile devices
- [ ] Verify all images load correctly
- [ ] Check page loading speed
- [ ] Test all navigation links
- [ ] Enable SSL certificate (HTTPS)

## Optional Enhancements

Consider adding:
- Google reCAPTCHA to prevent spam
- Google Analytics for tracking
- Live chat integration
- WhatsApp business integration
- SEO meta tags optimization
- Sitemap.xml for search engines
- robots.txt configuration

## Backup Recommendations

- Keep regular backups of your website files
- Export database regularly (if using DB storage)
- Store contact form submissions externally
- Maintain version control with Git

---

**Last Updated**: February 9, 2026
**Version**: 2.0
**Maintained by**: Dhavamani Technologies
