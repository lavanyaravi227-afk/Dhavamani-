# Dhavamani Technologies Website

A modern, responsive website for Dhavamani Technologies - Precision Electronics & Embedded Solutions.

## Features

- ✨ Modern, professional design with industrial aesthetic
- 📱 Fully responsive (Desktop, Tablet, Mobile)
- ⚡ Smooth animations and transitions
- 📧 Working contact form with PHP backend
- 🎨 Custom typography using Google Fonts (Orbitron, IBM Plex Mono, Manrope)
- 🔥 Optimized performance
- 💼 SEO-friendly structure

## File Structure

```
dhavamani-website/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # All styles and animations
├── js/
│   └── script.js       # JavaScript functionality
├── php/
│   └── contact.php     # Contact form handler
├── images/             # All website images
│   ├── dhavamani-logo.png    # Official Dhavamani logo
│   ├── logo.svg              # Alternative logo design
│   ├── favicon.png           # Browser favicon (PNG)
│   ├── favicon.svg           # Browser favicon (SVG)
│   ├── hero-bg.svg           # Hero section background
│   ├── embedded-system.svg   # Product 1 image
│   ├── hydro-controller.svg  # Product 2 image
│   ├── load-controller.svg   # Product 3 image
│   ├── service-development.svg  # Service icon 1
│   ├── service-upgrade.svg      # Service icon 2
│   └── engineering-diagram.svg  # About section diagram
└── README.md           # This file
```

## Images Included

The website includes the official Dhavamani Technologies branding along with custom-designed technical illustrations:

**Official Branding:**
- **Dhavamani Logo** (PNG) - Official company logo with shield design
- **Favicon** (PNG & SVG) - Browser tab icon

**Custom Technical Illustrations (SVG):**
- **Logo & Branding**: Professional logo with circuit design elements
- **Product Images**: Technical illustrations for each product line
- **Service Icons**: Visual representations of development and upgrade services
- **Background Graphics**: Subtle technical patterns and diagrams

**Note**: All images are SVG format for:
- Crisp display at any resolution
- Fast loading times
- Easy color customization
- Scalability without quality loss

To replace images with your own:
1. Keep the same filenames for easy swap
2. Recommended: Use SVG or high-quality PNG/JPG
3. Maintain aspect ratios for best display
4. Optimize images before upload for better performance

## Installation & Setup

### 1. Local Development (Simple HTML)

Just open `index.html` in your browser. The contact form won't work without PHP.

### 2. Local Server with PHP

#### Option A: Using XAMPP/WAMP/MAMP
1. Install XAMPP, WAMP, or MAMP
2. Copy the entire `dhavamani-website` folder to:
   - XAMPP: `C:/xampp/htdocs/`
   - WAMP: `C:/wamp64/www/`
   - MAMP: `/Applications/MAMP/htdocs/`
3. Start Apache server
4. Visit `http://localhost/dhavamani-website/`

#### Option B: Using PHP Built-in Server
```bash
cd dhavamani-website
php -S localhost:8000
```
Then visit `http://localhost:8000`

### 3. Production Deployment

#### Uploading to Web Server:
1. Upload all files to your web hosting via FTP/SFTP
2. Ensure PHP is enabled on your server (most hosting providers have this)
3. Update email addresses in `php/contact.php` (lines 40-41)
4. Set proper permissions:
   ```bash
   chmod 755 php/contact.php
   ```

#### Email Configuration:
Edit `php/contact.php` and update:
```php
$to = "your-email@yourdomain.com";
$from_email = "noreply@yourdomain.com";
```

## Configuration

### Contact Form Setup

1. **Email Configuration** (Required)
   - Open `php/contact.php`
   - Update line 40-41 with your email addresses
   - Update line 42 with your domain email for the "From" field

2. **Auto-Reply** (Optional)
   - Auto-reply is enabled by default
   - Customize the message in the `sendAutoReply()` function (lines 89-108)

3. **Database Storage** (Optional)
   - Uncomment the database functions (lines 112-139)
   - Configure database credentials
   - Create the table using the provided SQL (lines 142-152)

### Customization

#### Colors
Edit CSS variables in `css/style.css` (lines 1-11):
```css
:root {
    --primary-dark: #0a1628;
    --accent-orange: #ff6b35;
    --accent-cyan: #00d4ff;
    /* ... */
}
```

#### Content
- Edit `index.html` to change text, images, and structure
- Company information is in the Contact section
- Products and services can be added/modified in their respective sections

#### Fonts
Current fonts are loaded from Google Fonts. To change:
1. Update the `<link>` tag in `index.html` (line 9)
2. Update font-family in `css/style.css`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Performance Tips

1. **Image Optimization**: Add optimized images to improve load time
2. **Caching**: Enable browser caching on your server
3. **CDN**: Consider using a CDN for fonts and assets
4. **Minification**: Minify CSS and JS for production

## Security Recommendations

1. **Spam Protection**: Consider adding reCAPTCHA to the contact form
2. **Rate Limiting**: Implement rate limiting for form submissions
3. **HTTPS**: Always use HTTPS in production
4. **Input Validation**: The form has basic validation, but add server-side checks
5. **Email Headers**: Configure SPF and DKIM records for your domain

## Troubleshooting

### Contact Form Not Working
1. Check if PHP is installed: `php -v`
2. Verify PHP mail function is enabled
3. Check email server configuration
4. Review server error logs
5. Test with a simple PHP info page: `<?php phpinfo(); ?>`

### Styling Issues
1. Clear browser cache
2. Check if CSS file is loading (inspect in browser dev tools)
3. Verify file paths are correct

### Mobile Menu Not Showing
- JavaScript handles mobile menu creation
- Check browser console for errors
- Ensure `js/script.js` is loading properly

## Contact Information

**Dhavamani Technologies**
- Address: 79, P.M Colony, Rathanapuri, Coimbatore, Tamil Nadu, India
- Phone: +91 94451 25622
- Email: dhavamanitechnologies@gmail.com, contact@dhava.in
- Hours: 7:00 AM - 4:00 PM (365 days/year)

## License

© 2026 Dhavamani Technologies. All Rights Reserved.

## Support

For website support or customization requests, contact the development team or reach out to Dhavamani Technologies directly.

---

**Built with precision, engineered for excellence.**