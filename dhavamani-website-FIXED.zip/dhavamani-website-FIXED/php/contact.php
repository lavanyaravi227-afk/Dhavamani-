<?php
// Contact Form Handler for Dhavamani Technologies
// File: contact.php

// Set JSON response header
header('Content-Type: application/json');

// Enable error reporting for debugging (disable in production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Initialize response array
$response = array(
    'success' => false,
    'message' => ''
);

// Check if form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Sanitize and validate input
    $name = isset($_POST['name']) ? trim(strip_tags($_POST['name'])) : '';
    $email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? trim(strip_tags($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? trim(strip_tags($_POST['message'])) : '';
    
    // Validation
    $errors = array();
    
    if (empty($name)) {
        $errors[] = 'Name is required';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($message)) {
        $errors[] = 'Message is required';
    }
    
    // If there are validation errors
    if (!empty($errors)) {
        $response['message'] = implode(', ', $errors);
        echo json_encode($response);
        exit;
    }
    
    // Configuration - TESTING MODE - Using anu822109@gmail.com for testing
    $to = "anu822109@gmail.com"; // Testing email address
    $subject = "New Contact Form Submission - Dhavamani Technologies [TEST]";
    $from_email = "noreply@dhava.in"; // Update this to your domain email
    
    // Prepare email content
    $email_content = "New Contact Form Submission\n\n";
    $email_content .= "Name: " . $name . "\n";
    $email_content .= "Email: " . $email . "\n";
    $email_content .= "Phone: " . $phone . "\n\n";
    $email_content .= "Message:\n" . $message . "\n";
    $email_content .= "\n---\n";
    $email_content .= "Sent from: Dhavamani Technologies Website\n";
    $email_content .= "IP Address: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $email_content .= "Date: " . date('Y-m-d H:i:s') . "\n";
    
    // Email headers
    $headers = "From: " . $from_email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    // Send email
    if (mail($to, $subject, $email_content, $headers)) {
        $response['success'] = true;
        $response['message'] = 'Thank you for your message! We will get back to you soon.';
        
        // Optional: Save to database
        // saveToDB($name, $email, $phone, $message);
        
        // Optional: Send auto-reply to customer
        sendAutoReply($email, $name);
        
    } else {
        $response['message'] = 'Sorry, there was an error sending your message. Please try again or contact us directly at +91 94451 25622.';
    }
    
} else {
    $response['message'] = 'Invalid request method';
}

// Return JSON response
echo json_encode($response);

// Function to send auto-reply (optional)
function sendAutoReply($customer_email, $customer_name) {
    $subject = "Thank you for contacting Dhavamani Technologies";
    
    $message = "Dear " . $customer_name . ",\n\n";
    $message .= "Thank you for reaching out to Dhavamani Technologies!\n\n";
    $message .= "We have received your message and one of our team members will get back to you within 24 hours.\n\n";
    $message .= "In the meantime, feel free to call us at +91 94451 25622 if you need immediate assistance.\n\n";
    $message .= "Our operating hours:\n";
    $message .= "7:00 AM - 4:00 PM, 365 days a year\n\n";
    $message .= "Best regards,\n";
    $message .= "Dhavamani Technologies Team\n";
    $message .= "79, P.M Colony, Rathanapuri, Coimbatore\n";
    $message .= "www.dhava.in\n";
    
    $headers = "From: contact@dhava.in\r\n";
    $headers .= "Reply-To: anu822109@gmail.com\r\n";
    
    mail($customer_email, $subject, $message, $headers);
}

// Function to save to database (optional - uncomment and configure)
/*
function saveToDB($name, $email, $phone, $message) {
    // Database configuration
    $host = 'localhost';
    $dbname = 'your_database_name';
    $username = 'your_db_username';
    $password = 'your_db_password';
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = "INSERT INTO contact_submissions (name, email, phone, message, created_at) 
                VALUES (:name, :email, :phone, :message, NOW())";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':phone' => $phone,
            ':message' => $message
        ]);
        
        return true;
    } catch(PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        return false;
    }
}
*/

// Optional: Create database table with this SQL
/*
CREATE TABLE contact_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT
);
*/
?>