<?php
// Contact Form Handler for Dhavamani Technologies
// Enhanced version with better error handling and logging

// Set JSON response header
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to user
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Initialize response array
$response = array(
    'success' => false,
    'message' => '',
    'debug' => array()
);

// Log function for debugging
function logDebug($message) {
    $logFile = __DIR__ . '/form-debug.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

logDebug("Form submission received");

// Check if form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    logDebug("POST request confirmed");
    
    // Sanitize and validate input
    $name = isset($_POST['name']) ? trim(strip_tags($_POST['name'])) : '';
    $email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? trim(strip_tags($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? trim(strip_tags($_POST['message'])) : '';
    
    logDebug("Data received - Name: $name, Email: $email");
    
    // Validation
    $errors = array();
    
    if (empty($name)) {
        $errors[] = 'Name is required';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($message)) {
        $errors[] = 'Message is required';
    }
    
    // If there are validation errors
    if (!empty($errors)) {
        $response['message'] = implode(', ', $errors);
        logDebug("Validation errors: " . implode(', ', $errors));
        echo json_encode($response);
        exit;
    }
    
    // Configuration - TESTING MODE
    $to = "anu822109@gmail.com"; // Testing email
    $cc = "lavs12122003@gmail.com"; // Additional recipient for testing
    $subject = "New Contact Form Submission - Dhavamani Technologies [TEST]";
    $from_email = "noreply@dhava.in";
    
    // Prepare email content
    $email_content = "New Contact Form Submission\n\n";
    $email_content .= "Name: " . $name . "\n";
    $email_content .= "Email: " . $email . "\n";
    $email_content .= "Phone: " . $phone . "\n\n";
    $email_content .= "Message:\n" . $message . "\n";
    $email_content .= "\n---\n";
    $email_content .= "Sent from: Dhavamani Technologies Website\n";
    $email_content .= "IP Address: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $email_content .= "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\n";
    $email_content .= "Date: " . date('Y-m-d H:i:s') . "\n";
    
    // Email headers
    $headers = "From: " . $from_email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Cc: " . $cc . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    logDebug("Attempting to send email to: $to, $cc");
    
    // Try to send email
    $mail_sent = @mail($to, $subject, $email_content, $headers);
    
    if ($mail_sent) {
        logDebug("Email sent successfully");
        $response['success'] = true;
        $response['message'] = 'Thank you for your message! We will get back to you soon.';
        
        // Try to send auto-reply
        try {
            sendAutoReply($email, $name);
            logDebug("Auto-reply sent to: $email");
        } catch (Exception $e) {
            logDebug("Auto-reply failed: " . $e->getMessage());
        }
        
        // Save to text file as backup
        saveToFile($name, $email, $phone, $message);
        
    } else {
        logDebug("Mail function failed");
        
        // Save to text file as backup
        if (saveToFile($name, $email, $phone, $message)) {
            $response['success'] = true;
            $response['message'] = 'Your message has been saved! We will contact you soon. (Email service temporarily unavailable)';
            logDebug("Saved to file successfully");
        } else {
            $response['message'] = 'Sorry, there was an error. Please email us directly at anu822109@gmail.com or call +91 94451 25622.';
            $response['debug']['error'] = 'Mail function not available on this server';
            logDebug("Both email and file save failed");
        }
    }
    
} else {
    $response['message'] = 'Invalid request method';
    logDebug("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
}

// Return JSON response
echo json_encode($response);
logDebug("Response sent: " . json_encode($response));

// Function to send auto-reply
function sendAutoReply($customer_email, $customer_name) {
    $subject = "Thank you for contacting Dhavamani Technologies";
    
    $message = "Dear " . $customer_name . ",\n\n";
    $message .= "Thank you for reaching out to Dhavamani Technologies!\n\n";
    $message .= "We have received your message and one of our team members will get back to you within 24 hours.\n\n";
    $message .= "In the meantime, feel free to call us at +91 94451 25622 if you need immediate assistance.\n\n";
    $message .= "Our operating hours:\n";
    $message .= "7:00 AM - 4:00 PM, 365 days a year\n\n";
    $message .= "Best regards,\n";
    $message .= "Dhavamani Technologies Team\n";
    $message .= "79, P.M Colony, Rathanapuri, Coimbatore\n";
    $message .= "www.dhava.in\n";
    
    $headers = "From: contact@dhava.in\r\n";
    $headers .= "Reply-To: anu822109@gmail.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    return @mail($customer_email, $subject, $message, $headers);
}

// Function to save to text file as backup
function saveToFile($name, $email, $phone, $message) {
    try {
        $filename = __DIR__ . '/submissions.txt';
        $timestamp = date('Y-m-d H:i:s');
        
        $content = "\n==============================================\n";
        $content .= "SUBMISSION DATE: " . $timestamp . "\n";
        $content .= "==============================================\n";
        $content .= "Name: " . $name . "\n";
        $content .= "Email: " . $email . "\n";
        $content .= "Phone: " . $phone . "\n";
        $content .= "Message: " . $message . "\n";
        $content .= "IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
        $content .= "==============================================\n";
        
        $result = file_put_contents($filename, $content, FILE_APPEND);
        logDebug("File save result: " . ($result !== false ? 'success' : 'failed'));
        
        return $result !== false;
    } catch (Exception $e) {
        logDebug("File save exception: " . $e->getMessage());
        return false;
    }
}
?>
